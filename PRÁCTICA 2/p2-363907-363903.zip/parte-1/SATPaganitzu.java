//Librerias JaCOP
import org.jacop.core.BooleanVar;
import org.jacop.core.Store;
import org.jacop.jasat.utils.structures.IntVec;
import org.jacop.satwrapper.SatWrapper;
import org.jacop.search.DepthFirstSearch;
import org.jacop.search.IndomainMin;
import org.jacop.search.Search;
import org.jacop.search.SelectChoicePoint;
import org.jacop.search.SimpleSelect;
import org.jacop.search.SmallestDomain;

//Librerias Java (leer y escribir fichero)
import java.io.*;

class WhiteSquare {
	int row;
	int col;

	WhiteSquare(int row, int col) {
		this.row = row;
		this.col = col;
	}
}

//Programa principal SATPaganitzu
public class SATPaganitzu {
	//Funcion principal
	public static void main(String[] args) {
		//Comprobar numero de parametros
		if(args.length != 2) {
			System.err.println("Numero de parametros incorrecto");
			return;
		}
		//Comprobar segundo parametro
		try {
			Integer.parseInt(args[1]);
		}
		catch(NumberFormatException e) {
			System.err.println("El segundo parametro debe ser un numero natural");
			return;
		}
		//Leer el fichero
		int numWhiteSpaces = 0;
		char map[][] = null;

		//Parametros para leer el fichero
		String line;
		RandomAccessFile f = null;
		BufferedReader b = null;

		try {
			f = new RandomAccessFile(args[0], "r");
			line = f.readLine();
			map = new char[(int)f.length()/line.length()][line.length()];

            f.seek(0);

			//Espacios en blanco
			int i = 0;
			while ((line = f.readLine()) != null) {
				System.out.println(line);
				for(int j = 0; j < line.length(); j++) {
					map[i][j] = line.charAt(j);
					if(map[i][j] == ' ') {
						numWhiteSpaces++;
					}
				}
				i++;
			}
		}
		catch(FileNotFoundException e) {
			System.err.println(e.getMessage());
		}
		catch(IOException e) {
			System.err.println(e.getMessage());
		}
		finally {
			if(b != null) {
				try {
					f.close();
				}
				catch(IOException e) {
					e.getMessage();
				}
			}
		}

		WhiteSquare[] whites = new WhiteSquare[numWhiteSpaces];
		int whitesIndex = 0;

		//Problemas del SAT
		Store store = new Store();
		SatWrapper satWrapper = new SatWrapper();
		store.impose(satWrapper);
		BooleanVar allVariables[] = new BooleanVar[numWhiteSpaces * (1 + Integer.parseInt(args[1]))];

		int allVariablesIndex = 0;
		int player[][] = new int[map.length][map[0].length];
		int snakes[][][] = new int[Integer.parseInt(args[1])][map.length][map[0].length];

		//Declaracion de las variables
		for(int i = 0; i < map.length; i++) {
			for(int j = 0; j < map[i].length; j++) {
				if(map[i][j] == ' ') {

					whites[whitesIndex++] = new WhiteSquare(i, j);

					allVariables[allVariablesIndex] = new BooleanVar(store, "\n A " + Integer.toString(i) + " " + Integer.toString(j));
					satWrapper.register(allVariables[allVariablesIndex]);
					player[i][j] = satWrapper.cpVarToBoolVar(allVariables[allVariablesIndex], 1, true);
					allVariablesIndex++;

					for(int serpienteN = 0; serpienteN < Integer.parseInt(args[1]); serpienteN++) {
						allVariables[allVariablesIndex] = new BooleanVar(store, "\n S " + Integer.toString(serpienteN) + " " + Integer.toString(i) + " " + Integer.toString(j));
						satWrapper.register(allVariables[allVariablesIndex]);
						snakes[serpienteN][i][j] = satWrapper.cpVarToBoolVar(allVariables[allVariablesIndex], 1, true);
						allVariablesIndex++;
					}
				}
			}
		}

		//Generar restricciones en FNC

		//Restriccion solo se puede colocar como maximo un protagonista
		for(int i = 0; i < whites.length; i++)
		{
			for(int j = 0; j < whites.length; j++)
			{
				if(whites[i].row != whites[j].row || whites[i].col != whites[j].col) {
					//(-A[i,j] v -A[k,l]) AND (-A[i,j] v -A[k+1,l+1]) AND ...
					addClause(satWrapper, -player[whites[i].row][whites[i].col], -player[whites[j].row][whites[j].col]);
				}
			}
		}

		//Restriccion solo se puede colocar como minimo un protagonista
		int[] playersRestric = new int[numWhiteSpaces];
		int contador = 0;
		for(int i = 0; i < whites.length; i++)
		{
			playersRestric[contador++] = player[whites[i].row][whites[i].col];
		}
		//(A[i,j] v A[k,l] v A[k+1,l+1] v A[k+2,l+2] v ...)
		addClause(satWrapper, playersRestric);

		//Restriccion solo se puede colocar como maximo una serpiente con cada id
		for(int serpienteN = 0; serpienteN < Integer.parseInt(args[1]); serpienteN++)
		{
			for(int i = 0; i < whites.length; i++)
			{
				for(int j = 0; j < whites.length; j++)
				{
					if(whites[i].row != whites[j].row || whites[i].col != whites[j].col) {
						//(-A[i,j] v -A[k,l]) AND (-A[i,j] v -A[k+1,l+1]) AND ...
						addClause(satWrapper, -snakes[serpienteN][whites[i].row][whites[i].col], -snakes[serpienteN][whites[j].row][whites[j].col]);
					}
				}
			}
		}

		//Restriccion solo se puede colocar como minimo una serpiente con cada id
		for(int serpienteN = 0; serpienteN < Integer.parseInt(args[1]); serpienteN++)
		{
			int[] snakesRestric = new int[numWhiteSpaces];
			contador = 0;
			for(int i = 0; i < whites.length; i++)
			{
				snakesRestric[contador++] = snakes[serpienteN][whites[i].row][whites[i].col];
			}
			//(A[i,j] v A[k,l] v A[k+1,l+1] v A[k+2,l+2] v ...)
			addClause(satWrapper, snakesRestric);
		}

		//Restriccion solo puede haber una serpiente en una fila
		for(int i = 0; i < whites.length; i++)
		{
			for(int serpienteN = 0; serpienteN < Integer.parseInt(args[1]); serpienteN++)
			{
				for(int j = 0; j < whites.length; j++)
				{
					for(int serpienteM = 0; serpienteM < Integer.parseInt(args[1]); serpienteM++)
					{
						if(whites[i].row == whites[j].row && serpienteN != serpienteM) {
							//(-S[serpienteN][i,j] v -S[serpienteM][k,l]) AND (-S[serpienteN][i,j] v -S[serpienteM][k+1,l+1]) AND ... AND (-S[serpienteN][i,j] v -S[serpienteM+1][k,l]) AND (-S[serpienteN][i,j] v -S[serpienteM+1][k+1,l+1]) AND ...
							addClause(satWrapper, -snakes[serpienteN][whites[i].row][whites[i].col], -snakes[serpienteM][whites[j].row][whites[j].col]);
						}
					}
				}
			}
		}

		//Restriccion no puede haber un protagonista y una serpiente en la misma fila o columna
		for(int i = 0; i < whites.length; i++)
		{
			for(int j = 0; j < whites.length; j++)
			{
				for(int serpienteN = 0; serpienteN < Integer.parseInt(args[1]); serpienteN++)
				{
					if(whites[i].row == whites[j].row || whites[i].col == whites[j].col) {
						//(-A[i,j] v -S[serpienteN][k,l]) AND (-A[i,j] v -S[serpienteN][k,l+1]) AND ... AND (-A[i,j] v -S[serpienteN+1][k,l]) AND (-A[i,j] v -S[serpienteN+1][k,l+1]) AND ...
						addClause(satWrapper, -player[whites[i].row][whites[i].col], -snakes[serpienteN][whites[j].row][whites[j].col]);
					}
				}
			}
		}

		//Invocar al solucionador
		Search<BooleanVar> search = new DepthFirstSearch<BooleanVar>();
		SelectChoicePoint<BooleanVar> select = new SimpleSelect<BooleanVar>(allVariables, new SmallestDomain<BooleanVar>(), new IndomainMin<BooleanVar>());
		Boolean result = search.labeling(store, select);
		if(result) {
			System.out.println("PROBLEMA SATISFACIBLE");

			for(int i = 0; i < allVariables.length; i++) {
				if(allVariables[i].value() == 1) {
					String[] varName = allVariables[i].id().split(" ");
					map[Integer.parseInt(varName[varName.length - 2])][Integer.parseInt(varName[varName.length - 1])] = allVariables[i].id().charAt(2);
				}
			}

    		FileWriter ficheroSalida = null;
    		BufferedWriter br = null;

    		try {
    			ficheroSalida = new FileWriter(args[0]+".output");
    			br = new BufferedWriter(ficheroSalida);

				for(int i = 0; i < map.length; i++)
		        {
		            for(int j = 0; j < map[i].length; j++)
		            {
		                br.write(map[i][j]);
		            }
		            br.newLine();
		        }

    		}
    		catch(FileNotFoundException e) {
    			System.err.println(e.getMessage());
    		}
    		catch(IOException e) {
    			System.err.println(e.getMessage());
    		}
    		finally {
    			if(br != null) {
    				try {
    					br.close();
    				}
    				catch(IOException e) {
    					e.getMessage();
    				}
    			}
    		}
		}
		else {
			System.out.println("PROBLEMA NO SATISFACIBLE");
		}
	}

	//Funcion añadir clausula (solo 2)
	public static void addClause(SatWrapper satWrapper, int literal1, int literal2) {
		IntVec clause = new IntVec(satWrapper.pool);
		clause.add(literal1);
		clause.add(literal2);
		satWrapper.addModelClause(clause.toArray());
	}

	//Funcion añadir clausula (hasta n)
	public static void addClause(SatWrapper satWrapper, int[] literals) {
		IntVec clause = new IntVec(satWrapper.pool);
		for(int i = 0; i < literals.length; i++) {
			clause.add(literals[i]);
		}
		satWrapper.addModelClause(clause.toArray());
	}
}
